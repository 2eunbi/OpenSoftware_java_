package test;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class p8signup extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	
	private JTextField textField_3;
	String id;
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	
	public static void dbConnect() {
		String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
         url = "jdbc:odbc:namecard";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/baemin?useUnicode=yes&characterEncoding=UTF8";
        String sql = "Select * From member";
		try {
			conn = DriverManager.getConnection(url,"root","");
            stmt = conn.createStatement( );
            rs = stmt.executeQuery(sql);
            System.out.println("�����ͺ��̽� ���� ����!");            
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
            }
	}
	
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}
	
	

	/**
	 * Create the frame.
	 */
	public p8signup() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Well come to Baemin");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 25));
		lblNewLabel.setBounds(91, 24, 256, 45);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("�̸�");
		lblNewLabel_1.setBounds(33, 90, 100, 54);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("���̵�");
		lblNewLabel_2.setBounds(33, 154, 100, 54);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("��й�ȣ");
		lblNewLabel_3.setBounds(33, 218, 100, 54);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("�ּ�");
		lblNewLabel_4.setBounds(33, 327, 105, 54);
		contentPane.add(lblNewLabel_4);
		
		textField = new JTextField();
		textField.setBounds(160, 107, 215, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(160, 171, 215, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(160, 235, 215, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(160, 344, 215, 21);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnNewButton = new JButton("�ڷΰ���");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new p1intro().setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(242, 391, 105, 34);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("�����ϱ�");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dbConnect();
				try {
					query("insert","insert into member values("+textField.getText()+','+textField_1.getText()+','+textField_2.getText()+','+textField_3.getText()+','+textField_4.getText()+")");	
					id = textField.getText();
				} catch (Exception e) {
					System.out.print(e);
				}
				
				new p3main(id).setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(101, 391, 100, 34);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_5 = new JLabel("��ȭ��ȣ");
		lblNewLabel_5.setBounds(33, 302, 50, 15);
		contentPane.add(lblNewLabel_5);
		
		textField_3 = new JTextField();
		textField_3.setBounds(160, 299, 215, 21);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
	}

}
