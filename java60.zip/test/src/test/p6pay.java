package test;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JTextField;

public class p6pay extends JFrame {

	private JPanel contentPane;
	private JTable table;

	
	
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	private JTextField textField;
	
	public static void dbConnect() {
		String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
         url = "jdbc:odbc:namecard";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/baemin?useUnicode=yes&characterEncoding=UTF8";
        String sql = "Select * From member";
		try {
			conn = DriverManager.getConnection(url,"root","");
            stmt = conn.createStatement( );
            rs = stmt.executeQuery(sql);
            System.out.println("�����ͺ��̽� ���� ����!");            
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
            }
	}
	
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}
	


	/**
	 * Create the frame.
	 */
	public p6pay(String id,DefaultTableModel model,int c) {
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Baemin");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 26));
		lblNewLabel.setBounds(139, 26, 105, 38);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("�������");
		lblNewLabel_1.setBounds(10, 246, 78, 31);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("�ڷΰ���");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new p5menu(id).setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(243, 145, 93, 38);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("������ ����");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new p7complete(id).setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(10, 297, 115, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("������ü");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new p7complete(id).setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(151, 297, 93, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("ī�����");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new p7complete(id).setVisible(true);
				dispose();
			}
		});
		btnNewButton_3.setBounds(267, 297, 93, 23);
		contentPane.add(btnNewButton_3);
		
		JLabel lblNewLabel_2 = new JLabel("���� �޴�");
		lblNewLabel_2.setBounds(10, 84, 78, 23);
		contentPane.add(lblNewLabel_2);
		
		table = new JTable(model);
		table.setBounds(10, 117, 193, 100);
		contentPane.add(table);
		
		JLabel lblNewLabel_3 = new JLabel("������");
		lblNewLabel_3.setBounds(10, 351, 78, 15);
		contentPane.add(lblNewLabel_3);
		
		JButton btnNewButton_4 = new JButton("��Һ����ϱ�");
		btnNewButton_4.setBounds(243, 372, 117, 23);
		contentPane.add(btnNewButton_4);
		
		textField = new JTextField();
		textField.setBounds(10, 373, 193, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("New label");
		lblNewLabel_4.setBounds(240, 117, 50, 15);
		contentPane.add(lblNewLabel_4);
		
		lblNewLabel_4.setText(c+"");
		
		dbConnect();
		try {
			query("select", "select * from member where id like "+id);
			if(rs.next()) {
				textField.setText(rs.getString("addr"));
				System.out.println(rs.getString("addr"));
			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
