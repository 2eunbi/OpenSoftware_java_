package test;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class p4koreanfood extends JFrame {

	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public p4koreanfood(String id) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 470);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("�ѽ�");
		mnNewMenu.setFont(new Font("���� ����", Font.PLAIN, 29));
		menuBar.add(mnNewMenu);
		
		JMenu mnNewMenu_1 = new JMenu("���");
		mnNewMenu_1.setFont(new Font("���� ����", Font.PLAIN, 29));
		menuBar.add(mnNewMenu_1);
		
		JMenu mnNewMenu_2 = new JMenu("�߽�");
		mnNewMenu_2.setFont(new Font("���� ����", Font.PLAIN, 29));
		menuBar.add(mnNewMenu_2);
		menuBar.add(mnNewMenu_2);
		
		JMenu mnNewMenu_3 = new JMenu("�Ͻ�");
		mnNewMenu_3.setFont(new Font("���� ����", Font.PLAIN, 29));
		menuBar.add(mnNewMenu_3);
		menuBar.add(mnNewMenu_3);
		
		JMenu mnNewMenu_4 = new JMenu("�н�");
		mnNewMenu_4.setFont(new Font("���� ����", Font.PLAIN, 29));
		menuBar.add(mnNewMenu_4);
		menuBar.add(mnNewMenu_4);
		
		JMenu mnNewMenu_5 = new JMenu("����Ʈ");
		mnNewMenu_5.setFont(new Font("���� ����", Font.PLAIN, 27));
		menuBar.add(mnNewMenu_5);
		menuBar.add(mnNewMenu_5);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("�谡��");
		lblNewLabel.setBounds(10, 26, 298, 81);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("�̰���");
		lblNewLabel_1.setBounds(10, 117, 298, 81);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("�ڰ���");
		lblNewLabel_2.setBounds(10, 208, 298, 93);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("�ڷΰ���");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new p3main(id).setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(163, 311, 123, 37);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("�ֹ��ϱ�");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new p5menu(id).setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(335, 55, 93, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("�ֹ��ϱ�");
		btnNewButton_2.setBounds(335, 146, 93, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("�ֹ��ϱ�");
		btnNewButton_3.setBounds(335, 243, 93, 23);
		contentPane.add(btnNewButton_3);
	}
}
