package test;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class p3main extends JFrame {

	private JPanel contentPane;


	/**
	 * Create the frame.
	 */
	public p3main(String id) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Baemin");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 30));
		lblNewLabel.setBounds(140, 10, 121, 36);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("�ѽ�");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new p4koreanfood(id).setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(32, 124, 80, 80);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("���");
		btnNewButton_1.setBounds(159, 124, 80, 80);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("�߽�");
		btnNewButton_2.setBounds(293, 124, 80, 80);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("�Ͻ�");
		btnNewButton_3.setBounds(32, 267, 80, 80);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("�н�");
		btnNewButton_4.setBounds(159, 267, 80, 80);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("����Ʈ");
		btnNewButton_5.setBounds(293, 267, 80, 80);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("����������");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new p10mypage(id).setVisible(true);
				dispose();
			}
		});
		btnNewButton_6.setBounds(293, 56, 111, 23);
		contentPane.add(btnNewButton_6);
		
		JLabel lblNewLabel_1 = new JLabel(id + "�� �ݰ����ϴ�.");
		lblNewLabel_1.setBounds(10, 56, 146, 23);
		contentPane.add(lblNewLabel_1);
	}

}
