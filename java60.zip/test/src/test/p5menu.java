package test;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class p5menu extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	
	int c = 0; 
	
	String[] head = {"�޴�", "����"};
	DefaultTableModel model = new DefaultTableModel(head,0);
	
	DefaultTableModel model2 = new DefaultTableModel(head,0);



	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	private JTable table_1;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	
	public static void dbConnect() {
		String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
         url = "jdbc:odbc:namecard";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/baemin?useUnicode=yes&characterEncoding=UTF8";
        String sql = "Select * From member";
		try {
			conn = DriverManager.getConnection(url,"root","");
            stmt = conn.createStatement( );
            rs = stmt.executeQuery(sql);
            System.out.println("�����ͺ��̽� ���� ����!");            
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
            }
	}
	
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}
	void addtab() {
		try {
			dbConnect();
			query("select", "select * from kim");
			while(rs.next()) {
				model.addRow(new Object[] {rs.getString("menu"),
											rs.getString("price")});

				System.out.println(rs.getString("menu"));
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	

	public p5menu(String id) {
		addtab();
	
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("���� ��ǰ�� �谡�׿� ���Ű� ȯ���մϴ�.");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 17));
		lblNewLabel.setBounds(47, 36, 381, 50);
		contentPane.add(lblNewLabel);
		
		
		
		table = new JTable(model);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int a = table.getSelectedColumn();
				int b = table.getSelectedRow();
				String selected = (String) table.getValueAt(b,a);
				String selected2 = (String) table.getValueAt(b,a+1);
				int price = Integer.parseInt((String) table.getValueAt(b, a+1));
				
				System.out.println(selected);
				System.out.println(selected2);
				
				model2.addRow(new Object[] {selected,selected2});
				c += price;
				
				lblNewLabel_1.setText("�� ���� : "+c+"");
				
			}
		});
		table.setBounds(10, 89, 161, 214);
		contentPane.add(table);
		
		btnNewButton_1 = new JButton("�ڷΰ���");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new p4koreanfood(id).setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(78, 376, 93, 39);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("�ֹ��ϱ�");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {				
				new p6pay(id,model2,c).setVisible(true);
				dispose();
			
			}
		});
		btnNewButton_2.setBounds(220, 376, 93, 39);
		contentPane.add(btnNewButton_2);
		
		table_1 = new JTable(model2);
		table_1.setBounds(220, 127, 132, 176);
		contentPane.add(table_1);
		

		
		lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(220, 325, 112, 15);
		contentPane.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("��ٱ���");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 22));
		lblNewLabel_2.setBounds(220, 80, 96, 28);
		contentPane.add(lblNewLabel_2);
		
		
		
		
	}
}
