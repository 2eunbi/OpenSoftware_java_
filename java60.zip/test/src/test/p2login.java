package test;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class p2login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	
	String id;
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	private JTextField textField_3;
	
	public static void dbConnect() {
		String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
         url = "jdbc:odbc:namecard";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/baemin?useUnicode=yes&characterEncoding=UTF8";
        String sql = "Select * From member";
		try {
			conn = DriverManager.getConnection(url,"root","");
            stmt = conn.createStatement( );
            rs = stmt.executeQuery(sql);
            System.out.println("�����ͺ��̽� ���� ����!");            
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
            }
	}
	
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}

	/**
	 * Create the frame.
	 */
	public p2login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("���̵�");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 15));
		lblNewLabel.setBounds(51, 101, 71, 25);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("��й�ȣ");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(51, 146, 71, 25);
		contentPane.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setFont(new Font("����", Font.PLAIN, 15));
		textField.setBounds(150, 101, 212, 25);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("����", Font.PLAIN, 15));
		textField_1.setBounds(150, 146, 212, 25);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewButton = new JButton("�α����ϱ�");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					dbConnect();
					try {
						query("select","select * from member where id like "+textField.getText());	
						id = textField.getText();
						if(rs.next()) {
							new p3main(id).setVisible(true);
							dispose();
						}
					} catch (Exception e) {
						System.out.print(e);
					}
				
			}
		});
		btnNewButton.setBounds(160, 181, 103, 39);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("��й�ȣ�� �ؾ�����̳���?");
		btnNewButton_1.setBounds(115, 230, 202, 25);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("Baemin");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(159, 34, 115, 45);
		contentPane.add(lblNewLabel_1);
	}
}
