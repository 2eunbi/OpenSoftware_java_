package test;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;

public class p1intro extends JFrame {

	private JPanel contentPane;
	
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	
	public static void dbConnect() {
		String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
         url = "jdbc:odbc:namecard";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/baemin?useUnicode=yes&characterEncoding=UTF8";
        String sql = "Select * From member";
		try {
			conn = DriverManager.getConnection(url,"root","");
            stmt = conn.createStatement( );
            rs = stmt.executeQuery(sql);
            System.out.println("�����ͺ��̽� ���� ����!");            
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
            }
	}
	
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}

	/**
	 * Create the frame.
	 */
	public p1intro() {
		dbConnect();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("��� ���忡 ���� �� ȯ���մϴ�");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel.setBounds(56, 47, 307, 38);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("�α���");
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(new Color(255, 215, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new p2login().setVisible(true);
				dispose();
				
			}
		});
		btnNewButton.setBounds(59, 145, 115, 38);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("ȸ������");
		btnNewButton_1.setBackground(new Color(255, 215, 0));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new p8signup().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(248, 145, 115, 38);
		contentPane.add(btnNewButton_1);
	}
}
